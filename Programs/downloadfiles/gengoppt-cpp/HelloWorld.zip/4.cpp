#include <iostream>

int main() {
    const char* message = "Hello, World!";
    std::cout << message << std::endl;
    return 0;
}
