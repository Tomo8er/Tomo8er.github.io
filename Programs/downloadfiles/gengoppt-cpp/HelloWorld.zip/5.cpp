#include <iostream>

void printMessage() {
    std::cout << "Hello, World!" << std::endl;
}

int main() {
    printMessage();
    return 0;
}
