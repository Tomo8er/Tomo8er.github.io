#include <iostream>
#include <format>

int main() {
    std::cout << std::format("{}", "Hello, World!") << std::endl;
    return 0;
}
