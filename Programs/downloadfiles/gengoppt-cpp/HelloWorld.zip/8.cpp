#include <iostream>
#define MESSAGE "Hello, World!"

int main() {
    std::cout << MESSAGE << std::endl;
    return 0;
}